﻿namespace EmotionQuest.Models
{
    public class Stimulus
    {
        public string Id { get; set; }
        public string Description { get; set; }      
        public string CorrectEmotion { get; set; }    
    }
}